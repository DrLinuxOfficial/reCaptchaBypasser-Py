Creator : Dr.Linux
My Github : DrLinuxOfficial
Python Version : v3.8
OS : Windows(10,8.1,7) & Linux(All Distro)

This Package For Bypassing reCaptcha in Selenium Python .

This Package Is Made With Python Version 3.8 And May Not Work On Lower Versions .

It Is Possible That One Of Them Will Be Bypassed In Every 4 Attempts, 
But If The Internet Speed Is strong, 
It Will Also Be Bypassed In The First Attempt .

This Package Uses Artificial Intelligence Neural Networks,
To Convert Google reCaptcha Audio Files To Text And Bypass It .

This Package Is Open Source, But It Is Not Because It Is Copyrighted .

Warning :
   
   This Package Is Only For Understanding How To Bypass The reCaptcha,
   And It Is Up To The Person To Use It Incorrectly .
