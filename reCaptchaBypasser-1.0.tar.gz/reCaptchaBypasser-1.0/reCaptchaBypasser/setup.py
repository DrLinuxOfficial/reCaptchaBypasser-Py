from setuptools import setup

setup(name="reCaptchaBypasser",
version="1.0",
description="This Package For Bypassing Any reCaptcha For Selenium Python .",
long_description = "README.md",
long_description_content_type = "text/markdown",
url="https://github.com/DrLinuxOfficial/reCaptchaBypasser-Py",
author="Dr.Linux",
packages=["reCaptchaBypasser"])
